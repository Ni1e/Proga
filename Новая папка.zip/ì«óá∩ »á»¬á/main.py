from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtWidgets import QApplication, QMainWindow, QDialog
import sys
from PyQt6.QtSql import QSqlTableModel
from UserW import Ui_User
from AuthorizationW import Ui_Authorization
from RegistrationW import Ui_Registration
from DialogAdd import Ui_Dialog
from connection import Data


class Main(QMainWindow):
    def __init__(self):
        super().__init__()

        #окно регистрации
        self.reg = QMainWindow()
        self.ui_reg = Ui_Registration()
        self.ui_reg.setupUi(self.reg)

        self.ui_reg.btn_reg.clicked.connect(self.reg_process)
        self.ui_reg.btn_home.clicked.connect(self.open_au)

        #окно авторизации
        self.au = QMainWindow()
        self.ui_au = Ui_Authorization()
        self.ui_au.setupUi(self.au)

        self.ui_au.btn_enter_reg.clicked.connect(self.auth_process)
        self.ui_au.btn_home.clicked.connect(self.open_reg)


        # окно пользователя
        self.user = QMainWindow()
        self.ui_user = Ui_User()
        self.ui_user.setupUi(self.user)
        self.conn = Data()
        self.view_db()
        self.view_db_vac()

        self.ui_user.btn_home.clicked.connect(self.open_au_user)
        self.ui_user.btn_Add.clicked.connect(self.open_vac)
        self.ui_user.btn_Delete.clicked.connect(self.delete_va)
        self.ui_user.btn_respond.clicked.connect(self.search_va)

    def view_db(self):
        self.model = QSqlTableModel(self)
        self.model.setTable("вакансии")
        self.model.select()
        self.ui_user.tableView.setModel(self.model)

    def view_db_vac(self):
        self.model = QSqlTableModel(self)
        self.model.setTable("мои_вакансии")
        self.model.select()
        self.ui_user.tableView_2.setModel(self.model)

    def open_reg(self):
        self.au.close()
        self.reg.show()

    def open_au(self):
        self.reg.close()
        self.au.show()

    def open_au_user(self):
        self.user.close()
        self.au.show()


    def reg_process(self):
        name = self.ui_reg.edit_name_reg.text()
        login = self.ui_reg.edit_login_reg.text()
        password = self.ui_reg.edit_password_reg.text()
        if not login or not password:
            return
        user_query = self.conn.get_user(login, password)
        if user_query:
            return
        self.conn.add_user(login, password, name)
        self.au.show()
        self.reg.close()


    def auth_process(self):
        login = self.ui_au.edit_login_reg.text()
        password = self.ui_au.edit_password_reg.text()
        role = self.conn.get_user(login, password)

        if role:
            super_user = role.value(4)
            if super_user == 'yes':
                self.ui_user.btn_respond.hide()
                self.ui_user.tableView_2.hide()
                self.ui_user.l_respond.hide()
                self.ui_user.btn_Add.show()
                self.ui_user.btn_Delete.show()
                self.user.show()
                self.au.close()
                self.ui_user.l_vacancy.setGeometry(165, 80, 640, 41)
                self.ui_user.tableView.setGeometry(165, 120, 640, 411)
            elif super_user == 'no':
                self.ui_user.btn_Add.hide()
                self.ui_user.btn_Delete.hide()
                self.ui_user.btn_respond.show()
                self.ui_user.tableView_2.show()
                self.ui_user.l_respond.show()
                self.user.show()
                self.au.close()
                self.ui_user.l_vacancy.setGeometry(32, 80, 451, 41)
                self.ui_user.tableView.setGeometry(32, 120, 451, 411)

        return role.value(0)



    def open_vac(self):
        self.vac = QDialog()
        self.ui_vac = Ui_Dialog()
        self.ui_vac.setupUi(self.vac)
        self.vac.show()
        self.ui_vac.btn_Save.clicked.connect(self.add_vacancy)



    def add_vacancy(self):
        company = self.ui_vac.edit_CompanyName.toPlainText()
        name = self.ui_vac.edit_NameVacancy.toPlainText()
        experience = self.ui_vac.edit_Experience.toPlainText()
        shedule = self.ui_vac.edit_Schedule.toPlainText()
        wage = self.ui_vac.edit_Wage.toPlainText()

        self.conn.add_new(company, name, experience, shedule, wage)
        self.view_db()
        self.view_db_vac()
        self.vac.close()


    def delete_va(self):
        index = self.ui_user.tableView.selectedIndexes()[0]
        id = str(self.ui_user.tableView.model().data(index))
        self.conn.delete(id)
        self.view_db()
        self.view_db_vac()

    def search_va(self):
        index = self.ui_user.tableView.selectedIndexes()[0]
        id = str(self.ui_user.tableView.model().data(index))
        company = self.conn.search(id).value(1)
        print(company)
        name = self.conn.search(id).value(2)
        experience = self.conn.search(id).value(3)
        shedule = self.conn.search(id).value(4)
        wage = self.conn.search(id).value(5)
        self.conn.add_new_my(company, name, experience, shedule, wage)
        self.conn.delete(id)
        self.view_db_vac()
        self.view_db()










if __name__ == "__main__":
    app = QApplication(sys.argv)
    main = Main()

    main.au.show()
    sys.exit(app.exec())
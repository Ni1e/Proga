from PyQt6.QtSql import QSqlDatabase, QSqlQuery


class Data:
    def __init__(self):
        super(Data, self).__init__()
        self.create_connect()


    def create_connect(self):
        db = QSqlDatabase.addDatabase('QSQLITE')
        db.setDatabaseName("employment_db.db")

        if not db.open():

            return False

        query = QSqlQuery()
        query.exec("""CREATE TABLE IF NOT EXISTS пользователи (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      имя TEXT,
                      логин TEXT,
                      пароль TEXT,
                      super_user TEXT DEFAULT no)""")

        query.exec("""CREATE TABLE IF NOT EXISTS вакансии (id INTEGER PRIMARY KEY AUTOINCREMENT,
                                      компания TEXT,
                                      название TEXT,
                                      опыт TEXT,
                                      график TEXT,
                                      зарплата REAL)""")

        query.exec("""CREATE TABLE IF NOT EXISTS мои_вакансии (id INTEGER PRIMARY KEY AUTOINCREMENT,
                                      компания TEXT,
                                      название TEXT,
                                      опыт TEXT,
                                      график TEXT,
                                      зарплата REAL)""")

        return True

    def execute(self, sql_query, query_values=None):
        query = QSqlQuery()
        query.prepare(sql_query)

        if query_values is not None:
            for query_value in query_values:
                query.addBindValue(query_value)

        query.exec()
        return query

    def get_user(self, login, password):
        query = QSqlQuery()
        query.prepare("SELECT * FROM пользователи WHERE логин = ? AND пароль = ?")
        query.bindValue(0, login)
        query.bindValue(1, password)
        if query.exec() and query.next():
            return query.record()
        else:
            return None


    def add_user(self, login, password, name):
        sql_query = "INSERT INTO пользователи (логин, пароль, имя) VALUES (?, ?, ?)"
        self.execute(sql_query, [login, password, name])

    def add_new(self, company, name, experience, shedule, wage):
        sql_query = "INSERT INTO вакансии (компания, название, опыт, график, зарплата) VALUES (?, ?, ?, ?, ?)"
        self.execute(sql_query, [company, name, experience, shedule, wage])

    def delete(self, id):
        sql_query = "DELETE FROM вакансии WHERE id=?"
        self.execute(sql_query, [id])


    def add_new_my(self, company, name, experience, shedule, wage):
        sql_query = "INSERT INTO мои_вакансии (компания, название, опыт, график, зарплата) VALUES (?, ?, ?, ?, ?)"
        self.execute(sql_query, [company, name, experience, shedule, wage])

    def search(self, id):
            query = QSqlQuery()
            query.prepare("SELECT * FROM вакансии WHERE id=?")
            query.bindValue(0, id)
            if query.exec() and query.next():
                return query.record()
            else:
                return None